"""Simulator-independent execution interfaces."""
