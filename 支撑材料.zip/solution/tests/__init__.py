"""Problem B test suite."""
