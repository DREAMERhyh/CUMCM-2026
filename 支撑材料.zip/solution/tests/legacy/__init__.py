"""Legacy experiment regression tests."""
